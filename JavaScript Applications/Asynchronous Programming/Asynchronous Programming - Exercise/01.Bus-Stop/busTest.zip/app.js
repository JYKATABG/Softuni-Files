function getInfo() {
    const busUrl = "http://localhost:3030/jsonstore/bus/businfo"
    const stopId = document.getElementById('stopId');
    const stopName = document.getElementById('stopName');
    const busesDiv = document.getElementById('buses');
    fetch(`${busUrl}/${stopId.value}`)
    .then(response => response.json())
    .then(data => {
        const name = data.name
        const buses = data.buses

        stopName.textContent = name;
        busesDiv.innerHTML = "";
        Object.keys(buses).forEach(bus => {
            let li = document.createElement("li");
            li.textContent = `Bus ${bus} arrives in ${buses[bus]} minutes`
            busesDiv.appendChild(li);
        });
    })
    .catch(error => {
        stopName.textContent = "Error"
        busesDiv.innerHTML = "";
    });
}