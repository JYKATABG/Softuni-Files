exports.SECRET = 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d';

exports.paymentMethodsMap = {
    "crypto-wallet": "Crypto Wallet",
    "credit-card": "Credit Card",
    "debit-card": "Debit Card",
    "paypal": "PayPal"
}