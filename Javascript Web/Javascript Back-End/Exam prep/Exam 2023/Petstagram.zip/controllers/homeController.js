const router = require('express').Router();
const photoService = require('../services/photoService.js');

router.get('/', (req, res) => {
    res.render('home/home');
});

router.get('/', (req, res) => {
    res.render('home/404');
});

router.get('/profile', async (req, res) => {
    const user = await photoService.getUserData(req.user._id)
    const photos = await photoService.getAllPhotos(req.user._id)
    console.log(photos);

    res.render('home/profile', { user });
});

module.exports = router;