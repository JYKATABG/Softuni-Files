const { find } = require('../models/Photo.js');
const Photo = require('../models/Photo.js');
const User = require('../models/User.js');

exports.getAll = () => Photo.find({});

exports.getOne = (photoId) => Photo.findById(photoId);

exports.create = (ownerId, photoData) => Photo.create({ ...photoData, owner: ownerId });

exports.getUserData = (userId) => {
    const user = User.findById(userId).populate('username').lean();

    return user;
}

exports.getAllPhotos = (photoId) => {
    const photo = Photo.findById(photoId).populate('owner', ['image']).lean();

    return photo;
}

exports.comment = async (comment, userId, photoId) => {
    const photo = await Photo.findById(photoId);
    photo.commentList.push({ userId: userId, comment: comment });

    return photo.save();
}

exports.edit = (photoId, photoData) => Photo.findByIdAndUpdate(photoId, photoData);

exports.delete = (photoId) => Photo.findByIdAndDelete(photoId);